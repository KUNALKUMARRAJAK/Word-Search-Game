/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { WordCategory, PuzzleGrid, WordPosition } from '../types';

// Curated comprehensive word bank
export const WORD_BANK: Record<WordCategory, string[]> = {
  Cities: [
    'PARIS', 'LONDON', 'TOKYO', 'NEWYORK', 'SYDNEY', 'ROME', 'BERLIN', 'CAIRO', 'MUMBAI', 'BEIJING',
    'MOSCOW', 'MADRID', 'CHICAGO', 'BOSTON', 'SEATTLE', 'TORONTO', 'DUBAI', 'SEOUL', 'BANGKOK', 'VIENNA',
    'AMSTERDAM', 'BRUSSELS', 'DUBLIN', 'LISBON', 'ATHENS', 'PRAGUE', 'WARSAW', 'SINGAPORE', 'JAKARTA', 'MANILA'
  ],
  Countries: [
    'CANADA', 'FRANCE', 'EGYPT', 'BRAZIL', 'JAPAN', 'INDIA', 'ITALY', 'SPAIN', 'MEXICO', 'CHINA',
    'GERMANY', 'SWEDEN', 'NORWAY', 'TURKEY', 'GREECE', 'RUSSIA', 'VIETNAM', 'KENYA', 'PERU', 'CHILE',
    'FINLAND', 'AUSTRALIA', 'AUSTRIA', 'BELGIUM', 'COLOMBIA', 'DENMARK', 'IRELAND', 'ICELAND', 'MOROCCO', 'SWITZERLAND'
  ],
  Animals: [
    'TIGER', 'LION', 'ELEPHANT', 'GIRAFFE', 'CHIPMUNK', 'BEAR', 'WOLF', 'FOX', 'RABBIT', 'MONKEY',
    'PANDA', 'DOLPHIN', 'WHALE', 'SHARK', 'EAGLE', 'FALCON', 'PENGUIN', 'KANGAROO', 'KOALA', 'LEOPARD',
    'ZEBRA', 'CHEETAH', 'FLAMINGO', 'SQUIRREL', 'DEER', 'OCTOPUS', 'LLAMA', 'CAMEL', 'HIPPO', 'RHINO'
  ],
  Fruits: [
    'APPLE', 'BANANA', 'ORANGE', 'GRAPE', 'PEACH', 'MELON', 'CHERRY', 'LEMON', 'MANGO', 'PEAR',
    'BERRY', 'KIWI', 'PAPAYA', 'PLUM', 'APRICOT', 'AVOCADO', 'COCONUT', 'FIGS', 'GUAVA', 'LYCHEE',
    'OLIVE', 'PINEAPPLE', 'RAISIN', 'LIME', 'NECTARINE', 'POMEGRANATE', 'TANGERINE', 'WATERMELON', 'DATES', 'GRAPEFRUIT'
  ],
  Sports: [
    'SOCCER', 'TENNIS', 'HOCKEY', 'RUGBY', 'GOLF', 'BOXING', 'CHESS', 'ROWING', 'SAILING', 'KARATE',
    'CRICKET', 'BASEBALL', 'FOOTBALL', 'SQUASH', 'CURLING', 'SURFING', 'SKIING', 'SKATING', 'RUNNING', 'CYCLING',
    'SWIMMING', 'FENCING', 'ARCHERY', 'BOWLING', 'HANDBALL', 'BADMINTON', 'BILLIARDS', 'CLIMBING', 'JUDO', 'GYMNASTICS'
  ],
  Space: [
    'COMET', 'PLANET', 'GALAXY', 'NEBULA', 'ORBIT', 'STAR', 'METEOR', 'MOON', 'SUN', 'ASTEROID',
    'ROCKET', 'CRATER', 'GRAVITY', 'APOLLO', 'SATURN', 'JUPITER', 'MARS', 'VENUS', 'MERCURY', 'URANUS',
    'NEPTUNE', 'PLUTO', 'ASTRONAUT', 'COSMOS', 'TELESCOPE', 'HUBBLE', 'QUASAR', 'SUPERNOVA', 'ECLIPSE', 'PULSAR'
  ],
  Colors: [
    'AMBER', 'BEIGE', 'BLACK', 'BLUE', 'BRONZE', 'BROWN', 'COPPER', 'CRIMSON', 'CYAN', 'EMERALD',
    'GOLD', 'GRAY', 'GREEN', 'INDIGO', 'IVORY', 'LAVENDER', 'MAGENTA', 'MINT', 'NAVY', 'OLIVE',
    'ORANGE', 'PEACH', 'PINK', 'PLUM', 'PURPLE', 'RED', 'SILVER', 'TEAL', 'WHITE', 'YELLOW'
  ],
  Food: [
    'BREAD', 'BURGER', 'CHEESE', 'PASTA', 'PIZZA', 'SALAD', 'SOUP', 'SUGAR', 'HONEY', 'BUTTER',
    'CHOCOLATE', 'NOODLES', 'SUSHI', 'SANDWICH', 'WAFFLE', 'PANCAKE', 'POPCORN', 'COOKIE', 'DONUT', 'YOGURT',
    'STEAK', 'BACOB', 'RICE', 'CEREAL', 'OATMEAL', 'KETTLE', 'NUTS', 'PASTRY', 'OM_ELET', 'MUFFIN'
  ]
};

// Deterministic random generator based on seed
export function createRNG(seed: number) {
  let x = Math.sin(seed++) * 10000;
  return () => {
    x = Math.sin(seed++) * 10000;
    return x - Math.floor(x);
  };
}

// Format duration elegantly to mm:ss
export function formatTime(seconds: number): string {
  const mins = Math.floor(seconds / 60);
  const secs = seconds % 60;
  return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
}

// Layout metrics per difficulty
export interface LevelConfig {
  gridSize: number;
  wordCount: number;
  directions: number[][]; // [dr, dc] steps
  starsGoldTime: number; // 3-star limit (seconds)
  starsSilverTime: number; // 2-star limit (seconds)
}

export function getLevelConfig(level: number): LevelConfig {
  // Let directions be represented as [dr, dc]
  const RIGHT = [0, 1];
  const DOWN = [1, 0];
  const LEFT = [0, -1];
  const UP = [-1, 0];
  const DIAG_DR = [1, 1];
  const DIAG_UR = [-1, 1];
  const DIAG_DL = [1, -1];
  const DIAG_UL = [-1, -1];

  if (level <= 5) {
    // Easy Warmup
    return {
      gridSize: 7,
      wordCount: 3,
      directions: [RIGHT, DOWN],
      starsGoldTime: 30,
      starsSilverTime: 60,
    };
  } else if (level <= 15) {
    return {
      gridSize: 8,
      wordCount: 4,
      directions: [RIGHT, DOWN, DIAG_DR],
      starsGoldTime: 45,
      starsSilverTime: 90,
    };
  } else if (level <= 50) {
    // Medium
    return {
      gridSize: 9,
      wordCount: 5,
      directions: [RIGHT, DOWN, LEFT, UP, DIAG_DR, DIAG_UR],
      starsGoldTime: 70,
      starsSilverTime: 140,
    };
  } else if (level <= 150) {
    // Challenging
    return {
      gridSize: 10,
      wordCount: 6,
      directions: [RIGHT, DOWN, LEFT, UP, DIAG_DR, DIAG_UR, DIAG_DL],
      starsGoldTime: 100,
      starsSilverTime: 200,
    };
  } else {
    // Hard / Master
    return {
      gridSize: 11,
      wordCount: 7,
      directions: [RIGHT, DOWN, LEFT, UP, DIAG_DR, DIAG_UR, DIAG_DL, DIAG_UL],
      starsGoldTime: 140,
      starsSilverTime: 280,
    };
  }
}

// Generator of deterministic level database
export function generatePuzzle(level: number, categoryOverride?: WordCategory): { grid: PuzzleGrid; category: WordCategory } {
  const seed = level * 1234.56;
  const rng = createRNG(Math.round(seed));

  // Determine category deterministically
  const categories: WordCategory[] = ['Cities', 'Countries', 'Animals', 'Fruits', 'Sports', 'Space', 'Colors', 'Food'];
  const categoryIndex = Math.floor(rng() * categories.length);
  const category = categoryOverride || categories[categoryIndex];

  // Get words and shuffle from bank using deterministic RNG
  const wordsInBank = [...WORD_BANK[category]];
  // Simple Knuth-Fisher-Yates Shuffle with deterministic RNG
  for (let i = wordsInBank.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    [wordsInBank[i], wordsInBank[j]] = [wordsInBank[j], wordsInBank[i]];
  }

  const config = getLevelConfig(level);
  
  // Choose up to config.wordCount words that fit comfortably in gridSize
  const puzzleWords: string[] = [];
  for (const w of wordsInBank) {
    if (w.length <= config.gridSize) {
      puzzleWords.push(w.toUpperCase());
    }
    if (puzzleWords.length >= config.wordCount) {
      break;
    }
  }

  // Ensure we have words
  if (puzzleWords.length === 0) {
    puzzleWords.push('WORD');
  }

  // Initialize empty grid with null characters
  const size = config.gridSize;
  const cells: string[][] = Array(size).fill(0).map(() => Array(size).fill(''));
  const wordPositions: WordPosition[] = [];

  // Try placing each word
  for (const word of puzzleWords) {
    let placed = false;
    let attempts = 0;

    while (!placed && attempts < 150) {
      attempts++;
      // Pick random direction
      const dirIndex = Math.floor(rng() * config.directions.length);
      const [dr, dc] = config.directions[dirIndex];

      // Pick random starting cell
      const startR = Math.floor(rng() * size);
      const startC = Math.floor(rng() * size);

      // Verify bounds
      const endR = startR + dr * (word.length - 1);
      const endC = startC + dc * (word.length - 1);

      if (endR >= 0 && endR < size && endC >= 0 && endC < size) {
        // Verify intersection safety
        let canPlace = true;
        const coords: { r: number; c: number }[] = [];

        for (let i = 0; i < word.length; i++) {
          const currR = startR + dr * i;
          const currC = startC + dc * i;
          const currentCellChar = cells[currR][currC];
          
          if (currentCellChar !== '' && currentCellChar !== word[i]) {
            canPlace = false;
            break;
          }
          coords.push({ r: currR, c: currC });
        }

        if (canPlace) {
          // Write word into grid
          for (let i = 0; i < word.length; i++) {
            cells[coords[i].r][coords[i].c] = word[i];
          }
          wordPositions.push({
            rawWord: word,
            word,
            found: false,
            coords
          });
          placed = true;
        }
      }
    }
  }

  // Backfill empty spots with random letters
  const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  for (let r = 0; r < size; r++) {
    for (let c = 0; c < size; c++) {
      if (cells[r][c] === '') {
        const randIndex = Math.floor(rng() * alphabet.length);
        cells[r][c] = alphabet[randIndex];
      }
    }
  }

  return {
    grid: {
      size,
      cells,
      wordPositions
    },
    category
  };
}
