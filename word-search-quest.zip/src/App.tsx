/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Trophy, HelpCircle, Calendar, Star, Compass, ShoppingBag, PlusCircle, Sparkles, RefreshCw, Layers } from 'lucide-react';
import { UserProgress } from './types';
import { audio } from './utils/audio';
import SplashScreen from './components/SplashScreen';
import LevelSelector from './components/LevelSelector';
import PurchasePopup from './components/PurchasePopup';
import DailyChallenge from './components/DailyChallenge';
import MainGame from './components/MainGame';

// Storage configuration helpers
const PROGRESS_STORAGE_KEY = 'word_search_quest_user_progress_v3';

const DEFAULT_PROGRESS: UserProgress = {
  currentLevel: 1,
  coins: 200, // Balanced starting capital
  hintsCount: 3, // Starter hints
  levels: {},
  badges: []
};

export default function App() {
  const [showSplash, setShowSplash] = useState(true);
  const [progress, setProgress] = useState<UserProgress>(DEFAULT_PROGRESS);
  const [isLoadingStorage, setIsLoadingStorage] = useState(true);

  // Active Screen / Mode tabs ('adventure' = level mode, 'challenge' = daily challenge speedrun)
  const [activeTab, setActiveTab] = useState<'adventure' | 'challenge'>('adventure');

  // Popup overlay controls
  const [showLevelSelector, setShowLevelSelector] = useState(false);
  const [showStore, setShowStore] = useState(false);

  // Selected level number (default: latest unlocked adventure level)
  const [activeLevel, setActiveLevel] = useState(1);

  // Load progress from localStorage
  useEffect(() => {
    try {
      const raw = localStorage.getItem(PROGRESS_STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        setProgress(parsed);
        // Sync active level selector to current highest unlocked
        setActiveLevel(parsed.currentLevel || 1);
      }
    } catch (e) {
      console.warn('Failed to parse user progress', e);
    } finally {
      setIsLoadingStorage(false);
    }
  }, []);

  const saveProgress = (newProgress: UserProgress) => {
    setProgress(newProgress);
    try {
      localStorage.setItem(PROGRESS_STORAGE_KEY, JSON.stringify(newProgress));
    } catch (e) {
      console.error('Failed to write user progress', e);
    }
  };

  // Callback: User completed a challenge (either level or daily)
  const handleUpdateProgress = (newProgress: UserProgress) => {
    saveProgress(newProgress);
  };

  const handleLevelSelect = (levelNum: number) => {
    setActiveLevel(levelNum);
    setActiveTab('adventure');
    setShowLevelSelector(false);
  };

  // Callback: Store modal transactions
  const handleStorePurchase = (hintsGained: number, cost: number) => {
    const updated = { ...progress };
    updated.coins = Math.max(0, updated.coins - cost);
    updated.hintsCount += hintsGained;
    saveProgress(updated);
    setShowStore(false);
  };

  const handleGoToNextLevel = () => {
    const nextLvl = activeLevel + 1;
    if (nextLvl <= 500) {
      setActiveLevel(nextLvl);
    }
  };

  // Reset progress confirmation option
  const handleResetProgress = () => {
    if (window.confirm('Reset all completed levels, stars, badges, and tokens to start fresh?')) {
      audio.playClick();
      saveProgress(DEFAULT_PROGRESS);
      setActiveLevel(1);
    }
  };

  if (isLoadingStorage) {
    return (
      <div className="fixed inset-0 bg-slate-950 flex items-center justify-center text-white font-mono text-xs">
        Booting memory registers...
      </div>
    );
  }

  return (
    <div id="game-app-sandbox-root" className="min-h-screen bg-slate-950 flex flex-col relative select-none">
      
      {/* 1. Pre-Loader Startup Splash Screen */}
      <AnimatePresence>
        {showSplash && (
          <SplashScreen onComplete={() => setShowSplash(false)} />
        )}
      </AnimatePresence>

      {/* Main Container */}
      {!showSplash && (
        <div className="flex-grow flex flex-col relative max-w-md w-full mx-auto bg-slate-950 text-slate-100 shadow-2xl p-3 pb-8">
          
          {/* Top Logo Panel */}
          <div className="flex items-center justify-between px-3 py-1.5 mb-2 border-b border-slate-900 flex-shrink-0">
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 bg-emerald-500 rounded-full animate-ping" />
              <h1 className="font-black text-sm uppercase tracking-widest text-[#10b981]">
                Word Quest
              </h1>
            </div>
            
            <button
              onClick={() => {
                audio.playClick();
                setShowStore(true);
              }}
              className="px-3 py-1 bg-gradient-to-r from-amber-500/20 to-yellow-500/15 border border-amber-500/20 text-amber-400 rounded-full text-xs font-black flex items-center gap-1.5 hover:scale-105 cursor-pointer transition-all"
            >
              <ShoppingBag className="w-3.5 h-3.5" />
              Shop
            </button>
          </div>

          {/* Tab Selection Switches */}
          <div className="grid grid-cols-2 gap-2 bg-slate-900 p-1.5 rounded-2xl mb-4 border border-slate-850/80 flex-shrink-0">
            <button
              onClick={() => {
                audio.playClick();
                setActiveTab('adventure');
              }}
              className={`
                flex items-center justify-center gap-1.5 py-2.5 rounded-xl font-bold text-xs uppercase tracking-wider transition-all cursor-pointer
                ${activeTab === 'adventure' 
                  ? 'bg-gradient-to-r from-emerald-500 to-cyan-500 text-white font-black shadow shadow-emerald-500/10' 
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-850'
                }
              `}
            >
              <Layers className="w-3.5 h-3.5" />
              Adventure Levels
            </button>
            
            <button
              onClick={() => {
                audio.playClick();
                setActiveTab('challenge');
              }}
              className={`
                flex items-center justify-center gap-1.5 py-2.5 rounded-xl font-bold text-xs uppercase tracking-wider transition-all cursor-pointer
                ${activeTab === 'challenge' 
                  ? 'bg-gradient-to-r from-rose-500 to-amber-500 text-white font-black shadow shadow-rose-500/10' 
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-850'
                }
              `}
            >
              <Calendar className="w-3.5 h-3.5" />
              Daily Quest
            </button>
          </div>

          {/* Active View Router */}
          <div className="flex-grow flex flex-col justify-between">
            {activeTab === 'adventure' ? (
              <MainGame
                progress={progress}
                activeLevel={activeLevel}
                isDailyChallengeMode={false}
                onUpdateProgress={handleUpdateProgress}
                onOpenLevelSelector={() => setShowLevelSelector(true)}
                onOpenStore={() => setShowStore(true)}
                onGoToNextLevel={handleGoToNextLevel}
              />
            ) : (
              <div className="flex flex-col flex-grow justify-between gap-4">
                <DailyChallenge
                  onChallengeCompleted={(coins, badge) => {
                    const copied = { ...progress };
                    copied.coins += coins;
                    if (!copied.badges.includes(badge)) {
                      copied.badges.push(badge);
                    }
                    saveProgress(copied);
                  }}
                  lastDateCompleted={progress.lastDailyChallengeCompletedDate}
                />

                {/* Main Game link to help load layout instantly */}
                <div className="border-t border-slate-900 pt-4 px-1 flex-grow">
                  <div className="bg-slate-900 border border-slate-850 rounded-3xl p-4 text-center">
                    <span className="text-[10px] text-rose-400 font-extrabold tracking-widest uppercase">
                      DAILY PUZZLE PORTAL
                    </span>
                    <p className="text-xs text-slate-400 mt-2">
                      Ready to take on today's timed speed puzzle? Trigger challenge start above and use search mechanics.
                    </p>
                    <button
                      onClick={() => {
                        audio.playClick();
                        setActiveLevel(progress.currentLevel);
                        setActiveTab('adventure');
                      }}
                      className="mt-4 inline-flex items-center gap-1 text-xs font-bold text-emerald-400 hover:text-emerald-300"
                    >
                      ← Return to Adventure Level {progress.currentLevel}
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Trophies & Badges Case Display Drawer */}
          <div className="mt-4 bg-slate-900/60 border border-slate-850/60 rounded-3xl p-4 flex-shrink-0">
            <div className="flex items-center justify-between mb-2">
              <span className="text-[9px] text-slate-500 font-bold uppercase tracking-widest leading-none">
                TROPHY CASE & BADGES
              </span>
              <Trophy className="w-3.5 h-3.5 text-slate-500" />
            </div>

            <div className="grid grid-cols-3 gap-2">
              {/* Badge 1: Novice Explorer */}
              <div className={`
                p-2.5 rounded-2xl border text-center transition-all duration-300
                ${progress.badges.includes('explorer')
                  ? 'bg-rose-500/10 border-rose-500/20 text-rose-400'
                  : 'bg-slate-950/45 border-slate-900/30 text-slate-600 opacity-60'
                }
              `}>
                <div className="text-xs font-black tracking-tight leading-none">Explorer</div>
                <div className="text-[8px] text-slate-500 font-bold uppercase tracking-wide mt-1">Daily Run</div>
              </div>

              {/* Badge 2: Adept */}
              <div className={`
                p-2.5 rounded-2xl border text-center transition-all duration-300
                ${progress.badges.includes('adept')
                  ? 'bg-amber-500/10 border-amber-500/20 text-amber-400'
                  : 'bg-slate-950/45 border-slate-900/30 text-slate-600 opacity-60'
                }
              `}>
                <div className="text-xs font-black tracking-tight leading-none">Adept</div>
                <div className="text-[8px] text-slate-500 font-bold uppercase tracking-wide mt-1">Level 10+</div>
              </div>

              {/* Badge 3: Sensei */}
              <div className={`
                p-2.5 rounded-2xl border text-center transition-all duration-300
                ${progress.badges.includes('sensei')
                  ? 'bg-cyan-500/10 border-cyan-500/20 text-cyan-400'
                  : 'bg-slate-950/45 border-slate-900/30 text-slate-600 opacity-60'
                }
              `}>
                <div className="text-xs font-black tracking-tight leading-none">Sensei</div>
                <div className="text-[8px] text-slate-500 font-bold uppercase tracking-wide mt-1">Level 50+</div>
              </div>
            </div>
          </div>

          {/* Settings Reset Button footer */}
          <div className="mt-4 pt-2 border-t border-slate-900 flex justify-between items-center text-[10px] text-slate-600 font-medium font-mono px-1 flex-shrink-0">
            <span>© WORD SEARCH QUEST ENGINE</span>
            <button
              onClick={handleResetProgress}
              className="text-[#f43f5e] hover:text-[#e11d48] font-bold uppercase tracking-wider cursor-pointer"
            >
              Reset Memories
            </button>
          </div>

        </div>
      )}

      {/* 2. Slide Drawer Overlay: Infinite level browser */}
      <AnimatePresence>
        {showLevelSelector && (
          <LevelSelector
            progress={progress}
            onSelectLevel={handleLevelSelect}
            onClose={() => setShowLevelSelector(false)}
          />
        )}
      </AnimatePresence>

      {/* 3. Slide Drawer Overlay: Merchant Hint Refiller */}
      <AnimatePresence>
        {showStore && (
          <PurchasePopup
            currentCoins={progress.coins}
            currentHints={progress.hintsCount}
            onPurchase={handleStorePurchase}
            onClose={() => setShowStore(false)}
          />
        )}
      </AnimatePresence>

    </div>
  );
}
