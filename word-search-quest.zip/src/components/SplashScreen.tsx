/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Play, Sparkles } from 'lucide-react';
import { audio } from '../utils/audio';

interface SplashScreenProps {
  onComplete: () => void;
}

export default function SplashScreen({ onComplete }: SplashScreenProps) {
  const [progress, setProgress] = useState(0);
  const [loadingComplete, setLoadingComplete] = useState(false);

  // Smooth loading progression
  useEffect(() => {
    let current = 0;
    const interval = setInterval(() => {
      // Intentional variable scaling to simulate genuine micro-loading stages
      const increment = Math.floor(Math.random() * 8) + 4;
      current = Math.min(current + increment, 100);
      setProgress(current);

      if (current >= 100) {
        clearInterval(interval);
        setTimeout(() => {
          setLoadingComplete(true);
        }, 400); // Wait for transition
      }
    }, 120);

    return () => clearInterval(interval);
  }, []);

  const handlePlayClick = () => {
    // Unblocks Audio Context on mobile browsers
    audio.playClick();
    onComplete();
  };

  // Background flying elements
  const letters = ['W', 'O', 'R', 'D', 'S', 'E', 'A', 'R', 'C', 'H'];

  return (
    <div
      id="splash-screen-container"
      className="fixed inset-0 bg-radial from-slate-900 to-zinc-950 flex flex-col items-center justify-center overflow-hidden z-50 text-white select-none px-4"
    >
      {/* Decorative Floating Word Search grids in the background */}
      <div className="absolute inset-0 opacity-10 grid grid-cols-8 gap-4 p-8 pointer-events-none">
        {Array(48).fill(null).map((_, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0.2, scale: 0.8 }}
            animate={{ 
              opacity: [0.1, 0.4, 0.1],
              scale: [0.9, 1.1, 0.9],
            }}
            transition={{
              duration: 4 + (i % 5),
              repeat: Infinity,
              delay: i * 0.1,
            }}
            className="flex items-center justify-center font-mono text-2xl font-black text-emerald-400"
          >
            {letters[i % letters.length]}
          </motion.div>
        ))}
      </div>

      <div className="relative flex flex-col items-center z-10 w-full max-w-md text-center">
        {/* Animated Icon Box */}
        <motion.div
          id="splash-logo"
          initial={{ scale: 0, rotate: -180 }}
          animate={{ scale: 1, rotate: 0 }}
          transition={{ type: 'spring', stiffness: 100, damping: 15 }}
          className="w-24 h-24 bg-gradient-to-tr from-emerald-500 to-cyan-400 rounded-3xl flex items-center justify-center shadow-2xl shadow-emerald-500/20 mb-8 relative border border-emerald-300/20"
        >
          <Sparkles className="w-12 h-12 text-white animate-pulse" />
          <div className="absolute -top-1 -right-1 w-4 h-4 bg-amber-400 rounded-full animate-ping" />
        </motion.div>

        {/* Title */}
        <motion.h1
          id="splash-title"
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.2, duration: 0.6 }}
          className="text-4xl sm:text-5xl font-black tracking-tight text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 via-cyan-300 to-white mb-2"
        >
          WORD SEARCH
        </motion.h1>
        
        <motion.p
          id="splash-subtitle"
          initial={{ y: 15, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.3 }}
          className="text-slate-400 text-sm tracking-widest uppercase mb-12 font-semibold"
        >
          The Ultimate Quest
        </motion.p>

        {/* Content Switch: Loading Bar vs PLAY Button */}
        <div id="splash-action-container" className="w-full max-w-xs h-24 flex items-center justify-center">
          {!loadingComplete ? (
            <div className="w-full flex flex-col items-center">
              <div className="w-full bg-slate-800/80 rounded-full h-3.5 p-0.5 border border-slate-700/55 shadow-inner">
                <motion.div
                  id="splash-loading-indicator"
                  className="bg-gradient-to-r from-emerald-500 to-cyan-400 h-full rounded-full shadow-lg shadow-emerald-500/10"
                  style={{ width: `${progress}%` }}
                />
              </div>
              <motion.div
                id="splash-loading-text"
                className="mt-3 text-xs font-mono font-medium tracking-widest text-[#a855f7] bg-[#a855f7]/10 px-3 py-1 rounded-full border border-[#a855f7]/10"
                animate={{ opacity: [1, 0.5, 1] }}
                transition={{ duration: 1.5, repeat: Infinity }}
              >
                LOADING PUZZLE ENGINE ({progress}%)
              </motion.div>
            </div>
          ) : (
            <motion.button
              id="splash-btn-play"
              initial={{ scale: 0.6, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              whileHover={{ scale: 1.08 }}
              whileTap={{ scale: 0.95 }}
              onClick={handlePlayClick}
              className="w-full flex items-center justify-center gap-3 bg-gradient-to-r from-emerald-500 via-teal-400 to-cyan-500 text-white font-extrabold text-xl py-4 px-8 rounded-2xl shadow-xl shadow-emerald-500/30 hover:shadow-cyan-500/40 border border-emerald-300/35 transition-all outline-none cursor-pointer"
            >
              <Play className="w-6 h-6 fill-current text-white" />
              PLAY NOW
            </motion.button>
          )}
        </div>
      </div>

      {/* Humble, Professional display tag in bottom */}
      <div id="splash-footer" className="absolute bottom-6 text-xs text-slate-500 font-medium font-mono select-none pointer-events-none">
        VERSION 2.1.0 • SMOOTH RENDER ACTIVE
      </div>
    </div>
  );
}
