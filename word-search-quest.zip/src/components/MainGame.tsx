/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Star, Coins, Sparkles, RefreshCcw, Volume2, VolumeX, Menu, Clock, 
  ChevronRight, Compass, HelpCircle, Trophy, ShoppingBag, Flame 
} from 'lucide-react';
import { UserProgress, PuzzleGrid, SelectionState, FeedbackText, WordPosition } from '../types';
import { generatePuzzle, getLevelConfig, formatTime, createRNG } from '../utils/words';
import { audio } from '../utils/audio';
import Confetti from './Confetti';

interface MainGameProps {
  progress: UserProgress;
  activeLevel: number;
  isDailyChallengeMode: boolean;
  onUpdateProgress: (newProgress: UserProgress) => void;
  onOpenLevelSelector: () => void;
  onOpenStore: () => void;
  onGoToNextLevel: () => void;
}

export default function MainGame({
  progress,
  activeLevel,
  isDailyChallengeMode,
  onUpdateProgress,
  onOpenLevelSelector,
  onOpenStore,
  onGoToNextLevel
}: MainGameProps) {
  // Game Setup States
  const [grid, setGrid] = useState<PuzzleGrid | null>(null);
  const [activeCategory, setActiveCategory] = useState<any>('');
  
  // Timer States
  const [seconds, setSeconds] = useState(0);
  const [timerActive, setTimerActive] = useState(false);
  
  // Custom Daily timer countdown
  const [dailyCountdown, setDailyCountdown] = useState(120); // 2 mins speed run

  // Touch & Swipe Selection State
  const [selection, setSelection] = useState<SelectionState>({
    start: null,
    current: null,
    selectedCells: []
  });
  const [isSelecting, setIsSelecting] = useState(false);

  // Audio mute toggles
  const [sfxMute, setSfxMute] = useState(!audio.isSfxEnabled());
  const [musicMute, setMusicMute] = useState(!audio.isMusicEnabled());

  // Win Popup Overlay State
  const [showWinPopup, setShowWinPopup] = useState(false);
  const [winStars, setWinStars] = useState(0);
  const [winCoinsEarned, setWinCoinsEarned] = useState(0);
  const [streakBadge, setStreakBadge] = useState<string | null>(null);

  // Real-time floating praise bubbles when found
  const [feedbackBubbles, setFeedbackBubbles] = useState<FeedbackText[]>([]);
  const [lastFoundTime, setLastFoundTime] = useState<number>(0);

  // Grid container reference for swipe bounding coords
  const gridRef = useRef<HTMLDivElement | null>(null);

  // Predefined gorgeous word find highlights
  const wordColors = [
    'rgba(16, 185, 129, 0.35)', // emerald
    'rgba(59, 130, 246, 0.35)', // blue
    'rgba(245, 158, 11, 0.35)', // amber
    'rgba(139, 92, 246, 0.35)', // violet
    'rgba(236, 72, 153, 0.35)', // pink
    'rgba(6, 182, 212, 0.35)',  // cyan
    'rgba(244, 63, 94, 0.35)'   // rose
  ];

  // Initialize Puzzle
  useEffect(() => {
    initLevel();
  }, [activeLevel, isDailyChallengeMode]);

  const initLevel = () => {
    // Generate deterministic puzzle layout
    const { grid: generatedGrid, category } = generatePuzzle(
      isDailyChallengeMode ? 999 : activeLevel
    );
    setGrid(generatedGrid);
    setActiveCategory(category);
    setSeconds(0);
    setDailyCountdown(120);
    setTimerActive(true);
    setShowWinPopup(false);
    setSelection({ start: null, current: null, selectedCells: [] });
    setIsSelecting(false);
    setLastFoundTime(0);
    setFeedbackBubbles([]);
  };

  // Timer run loop
  useEffect(() => {
    let interval: any = null;
    if (timerActive && !showWinPopup) {
      interval = setInterval(() => {
        if (isDailyChallengeMode) {
          setDailyCountdown((prev) => {
            if (prev <= 1) {
              // Time's up daily challenge loss!
              setTimerActive(false);
              initLevel(); // Hard restart challenge
              return 120;
            }
            return prev - 1;
          });
        }
        setSeconds((prev) => prev + 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [timerActive, showWinPopup, isDailyChallengeMode]);

  // Audio Context Toggle Helper
  const toggleSfx = () => {
    const nextVal = !sfxMute;
    setSfxMute(nextVal);
    audio.setSfxEnabled(!nextVal);
    audio.playClick();
  };

  const toggleMusic = () => {
    const nextVal = !musicMute;
    setMusicMute(nextVal);
    audio.setMusicEnabled(!nextVal);
    audio.playClick();
  };

  // Safe Index Checker
  const getCellRowCol = (cellEl: HTMLElement): { r: number; c: number } | null => {
    const rStr = cellEl.getAttribute('data-row');
    const cStr = cellEl.getAttribute('data-col');
    if (rStr !== null && cStr !== null) {
      return { r: parseInt(rStr, 10), c: parseInt(cStr, 10) };
    }
    return null;
  };

  // Check if Coordinates form a straight standard direction
  const calculateSelectionCells = (start: { r: number; c: number }, end: { r: number; c: number }) => {
    const dr = end.r - start.r;
    const dc = end.c - start.c;
    
    // Aligned in horizontal, vertical, or diagonal!
    const isStraight = dr === 0 || dc === 0 || Math.abs(dr) === Math.abs(dc);
    if (!isStraight) return [];

    const steps = Math.max(Math.abs(dr), Math.abs(dc));
    const stepR = steps === 0 ? 0 : dr / steps;
    const stepC = steps === 0 ? 0 : dc / steps;

    const list: { r: number; c: number }[] = [];
    for (let i = 0; i <= steps; i++) {
      list.push({
        r: start.r + Math.round(stepR * i),
        c: start.c + Math.round(stepC * i)
      });
    }
    return list;
  };

  // Unified Start Selection Handler
  const handleStartSelection = (r: number, c: number) => {
    if (showWinPopup) return;
    audio.playTick();
    setIsSelecting(true);
    setSelection({
      start: { r, c },
      current: { r, c },
      selectedCells: [{ r, c }]
    });
  };

  // Unified Hover move selection calculator (Mouse Pointer)
  const handleHoverCell = (r: number, c: number) => {
    if (!isSelecting || !selection.start) return;
    const cells = calculateSelectionCells(selection.start, { r, c });
    if (cells.length > 0) {
      // Play brief high pitch click on changing selection lengths
      if (cells.length !== selection.selectedCells.length) {
        audio.playTick();
      }
      setSelection((prev) => ({
        ...prev,
        current: { r, c },
        selectedCells: cells
      }));
    }
  };

  // TOUCH Handler (translates screen client coordinate swipes to index blocks)
  const handleTouchMove = (e: React.TouchEvent) => {
    if (!isSelecting || !selection.start || !gridRef.current) return;
    const touch = e.touches[0];
    const targetElement = document.elementFromPoint(touch.clientX, touch.clientY) as HTMLElement;
    
    if (targetElement) {
      const parentCellOffset = targetElement.closest('[data-cell-index]');
      if (parentCellOffset) {
        const indices = getCellRowCol(parentCellOffset as HTMLElement);
        if (indices) {
          const cells = calculateSelectionCells(selection.start, indices);
          if (cells.length > 0 && cells.length !== selection.selectedCells.length) {
            audio.playTick();
            setSelection((prev) => ({
              ...prev,
              current: indices,
              selectedCells: cells
            }));
          }
        }
      }
    }
  };

  // Finish swipe / selection evaluator
  const handleEndSelection = () => {
    if (!isSelecting || !grid) return;
    setIsSelecting(false);

    const cellsSelected = selection.selectedCells;
    if (cellsSelected.length < 2) {
      // Clear empty selections
      setSelection({ start: null, current: null, selectedCells: [] });
      return;
    }

    // Translate coordinates to selected word characters
    const selectedWordChars = cellsSelected.map((coord) => grid.cells[coord.r][coord.c]).join('');
    const reversedWordChars = [...selectedWordChars].reverse().join('');

    // Check if word matched
    let foundIndex = -1;
    let isReversed = false;

    grid.wordPositions.forEach((pos, idx) => {
      if (pos.found) return;
      if (pos.word === selectedWordChars) {
        foundIndex = idx;
      } else if (pos.word === reversedWordChars) {
        foundIndex = idx;
        isReversed = true;
      }
    });

    if (foundIndex !== -1) {
      // We found a target word! Mark state
      const targetPos = grid.wordPositions[foundIndex];
      targetPos.found = true;
      audio.playWordFound();

      // Trigger Smart Feedback Banner based on speed
      const nowMs = Date.now();
      const elapsedSincePrefix = nowMs - lastFoundTime;
      setLastFoundTime(nowMs);

      let ratingText = 'Word Found!';
      if (lastFoundTime > 0 && elapsedSincePrefix < 3500) {
        ratingText = 'Lightning Fast! ⚡';
      } else if (lastFoundTime > 0 && elapsedSincePrefix < 7000) {
        ratingText = 'Excellent Speed! 🔥';
      } else {
        const randomPraise = ['Nice!', 'Great Job!', 'Awesome!', 'Spot On!', 'Splendid!'];
        ratingText = randomPraise[Math.floor(Math.random() * randomPraise.length)];
      }

      // Append bubble over the board center
      const newBubble: FeedbackText = {
        id: Math.random().toString(),
        text: ratingText,
        x: Math.random() * 80 + 10,
        y: Math.random() * 20 + 40
      };
      setFeedbackBubbles((prev) => [...prev, newBubble]);

      // Highlight update
      setGrid({ ...grid });

      // Check level victory state
      const allFound = grid.wordPositions.every((pos) => pos.found);
      if (allFound) {
        handleLevelComplete();
      }
    }

    // Reset current active trail outline
    setSelection({ start: null, current: null, selectedCells: [] });
  };

  // Filter out bubbles as they decay
  const handleRemoveBubble = (id: string) => {
    setFeedbackBubbles((prev) => prev.filter((b) => b.id !== id));
  };

  // Hint Solver Logic
  const handleTriggerHint = () => {
    if (!grid) return;

    if (progress.hintsCount <= 0) {
      // Trigger out of hits store bundle popup
      audio.playClick();
      onOpenStore();
      return;
    }

    // Find first remaining word
    const remaining = grid.wordPositions.find((p) => !p.found);
    if (!remaining) return;

    audio.playRefill();
    // Use up 1 hint
    const updatedProgress = { ...progress };
    updatedProgress.hintsCount = Math.max(0, updatedProgress.hintsCount - 1);
    onUpdateProgress(updatedProgress);

    // Briefly highlight first coordinate as gold rings/flashes
    const rootCoord = remaining.coords[0];
    const firstCellEl = document.querySelector(`[data-row="${rootCoord.r}"][data-col="${rootCoord.c}"]`);
    if (firstCellEl) {
      firstCellEl.classList.add('animate-[#ffffff_1s_infinite]');
      firstCellEl.classList.add('bg-amber-400', 'text-black', 'scale-110', 'shadow-amber-500/50');
      setTimeout(() => {
        firstCellEl.classList.remove('bg-amber-400', 'text-black', 'scale-110', 'shadow-amber-500/50');
      }, 4000); // Remain highlighted for 4 seconds to help them
    }
  };

  // Calculate Stars Earned and Coin distribution on level ending
  const handleLevelComplete = () => {
    if (!grid) return;
    setTimerActive(false);
    audio.playWin();

    // Determine star metrics based on levels config thresholds
    const conf = getLevelConfig(isDailyChallengeMode ? 999 : activeLevel);
    let starsEarned = 1;
    if (isDailyChallengeMode) {
      starsEarned = dailyCountdown >= 60 ? 3 : dailyCountdown >= 30 ? 2 : 1;
    } else {
      starsEarned = seconds <= conf.starsGoldTime ? 3 : seconds <= conf.starsSilverTime ? 2 : 1;
    }

    // Coins calculations
    let basePayout = isDailyChallengeMode ? 150 : 35;
    let speedBonus = 0;
    if (starsEarned === 3) speedBonus = 15;
    else if (starsEarned === 2) speedBonus = 5;

    const coinsPayout = basePayout + speedBonus;

    // Save records
    const nextProgress = { ...progress };
    
    if (isDailyChallengeMode) {
      // Save daily date completion
      const d = new Date();
      const y = d.getFullYear();
      const m = String(d.getMonth() + 1).padStart(2, '0');
      const day = String(d.getDate()).padStart(2, '0');
      const dateStr = `${y}-${m}-${day}`;
      nextProgress.lastDailyChallengeCompletedDate = dateStr;

      // Add badge
      if (!nextProgress.badges.includes('explorer')) {
        nextProgress.badges.push('explorer');
        setStreakBadge('Explorer Badge Unlocked! 🧭');
      }
    } else {
      // Check high scores
      const existingLvl = nextProgress.levels[activeLevel];
      const highestStars = Math.max(existingLvl?.stars || 0, starsEarned);
      
      nextProgress.levels[activeLevel] = {
        levelNumber: activeLevel,
        stars: highestStars,
        bestTime: existingLvl?.bestTime ? Math.min(existingLvl.bestTime, seconds) : seconds
      };

      // Proceed sequential unlock limits
      if (activeLevel === nextProgress.currentLevel && activeLevel < 500) {
        nextProgress.currentLevel = activeLevel + 1;
      }

      // Achievement streak badge
      if (activeLevel >= 10 && !nextProgress.badges.includes('adept')) {
        nextProgress.badges.push('adept');
        setStreakBadge('Word Adept Badge Unlocked! ⭐');
      }
      if (activeLevel >= 50 && !nextProgress.badges.includes('sensei')) {
        nextProgress.badges.push('sensei');
        setStreakBadge('Puzzle Sensei Badge Unlocked! 👑');
      }
    }

    nextProgress.coins += coinsPayout;
    
    // Earn Hints based on level star performance
    if (starsEarned === 3 && !isDailyChallengeMode) {
      nextProgress.hintsCount += 1; // Reward bonus hints for 3 stars!
    }

    onUpdateProgress(nextProgress);
    setWinStars(starsEarned);
    setWinCoinsEarned(coinsPayout);
    setShowWinPopup(true);
  };

  // Check if grid coordinates are highlighted as already found
  const getCellHighlightColor = (r: number, c: number) => {
    if (!grid) return null;
    let foundColor: string | null = null;
    grid.wordPositions.forEach((pos, idx) => {
      if (!pos.found) return;
      const partOfWord = pos.coords.some((co) => co.r === r && co.c === c);
      if (partOfWord) {
        foundColor = wordColors[idx % wordColors.length];
      }
    });
    return foundColor;
  };

  const isCellInSelection = (r: number, c: number) => {
    return selection.selectedCells.some((co) => co.r === r && co.c === c);
  };

  const isCompletedWord = (word: string) => {
    if (!grid) return false;
    return grid.wordPositions.some((pos) => pos.word === word && pos.found);
  };

  return (
    <div id="playing-stage-outer" className="flex flex-col flex-grow w-full max-w-lg mx-auto relative px-3 py-2 text-white select-none">
      
      {/* 1. Header controls */}
      <div id="playing-stage-header" className="flex items-center justify-between gap-2 py-2 flex-shrink-0">
        
        {/* Toggle / Menu drawer activator */}
        <button
          onClick={() => {
            audio.playClick();
            onOpenLevelSelector();
          }}
          className="bg-slate-900 border border-slate-800 p-2.5 rounded-2xl hover:bg-slate-850 cursor-pointer text-slate-350 hover:text-white transition"
          title="Browse Levels"
        >
          <Menu className="w-5 h-5" />
        </button>

        {/* Current Level title badge */}
        <div className="flex flex-col text-center">
          <span className="text-[10px] text-slate-400 font-bold uppercase tracking-widest leading-none">
            {isDailyChallengeMode ? 'DAILY TIMED RUN' : 'CURRENT TIER'}
          </span>
          <span className="text-lg font-black text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-cyan-300">
            {isDailyChallengeMode ? 'Challenge' : `Level ${activeLevel}`}
          </span>
        </div>

        {/* Dynamic ticking stopwatch */}
        <div className="bg-slate-950/40 border border-slate-850/80 rounded-2xl py-1.5 px-3 flex items-center gap-1 text-slate-300 font-mono text-sm shadow-inner min-w-[70px] justify-center">
          <Clock className={`w-3.5 h-3.5 text-${isDailyChallengeMode ? 'rose' : 'cyan'}-400 animate-pulse`} />
          {isDailyChallengeMode ? formatTime(dailyCountdown) : formatTime(seconds)}
        </div>

        {/* Settings options bundle (Audio toggle buttons) */}
        <div className="flex gap-1.5">
          <button
            onClick={toggleSfx}
            className={`p-2.5 rounded-2xl border cursor-pointer transition ${
              sfxMute 
                ? 'bg-red-950/20 border-red-900/35 text-red-400' 
                : 'bg-slate-900 border-slate-800 text-slate-350 hover:text-white'
            }`}
            title="Silence SFX"
          >
            {sfxMute ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
          </button>
          
          <button
            onClick={toggleMusic}
            className={`p-2.5 rounded-2xl border cursor-pointer transition ${
              musicMute 
                ? 'bg-red-950/20 border-red-900/35 text-red-400' 
                : 'bg-slate-900 border-slate-800 text-slate-350 hover:text-white'
            }`}
            title="Silence Space Pad"
          >
            <span className="font-bold text-xs uppercase leading-none tracking-widest">
              {musicMute ? 'PAD OFF' : 'PAD ON'}
            </span>
          </button>
        </div>
      </div>

      {/* 2. Ledger balance bar */}
      <div id="playing-stage-ledger" className="grid grid-cols-2 gap-2 mt-1 mb-3 flex-shrink-0">
        <div className="bg-slate-900/90 border border-slate-850/70 rounded-2xl py-2.5 px-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Coins className="w-5 h-5 text-amber-400 fill-current" />
            <span className="text-xs font-semibold text-slate-400">Coins</span>
          </div>
          <span className="text-base font-black text-amber-400 tracking-wide">{progress.coins}</span>
        </div>

        <button
          onClick={handleTriggerHint}
          className="bg-slate-900/90 border border-slate-850/70 hover:bg-slate-850 rounded-2xl py-2.5 px-4 flex items-center justify-between cursor-pointer group transition-all"
        >
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-[#a855f7] group-hover:scale-110 transition-transform" />
            <span className="text-xs font-semibold text-slate-400">Hints</span>
          </div>
          <div className="flex items-center gap-1">
            <span className="text-base font-black text-[#a855f7]">{progress.hintsCount}</span>
            {progress.hintsCount === 0 && (
              <ShoppingBag className="w-3.5 h-3.5 text-[#a855f7]/60 ml-0.5 animate-bounce" />
            )}
          </div>
        </button>
      </div>

      {/* 3. Category banner layout */}
      <div id="playing-stage-category" className="bg-gradient-to-r from-emerald-500/10 via-cyan-500/5 to-slate-900 border border-slate-800 rounded-2xl p-3 text-center mb-3.5 flex-shrink-0 relative overflow-hidden">
        <Compass className="absolute -left-4 -top-4 w-12 h-12 text-emerald-400/5 pointer-events-none" />
        <span className="text-[10px] text-emerald-400 font-extrabold tracking-widest uppercase">
          TOPIC CATEGORY
        </span>
        <h2 className="text-lg font-black tracking-tight text-white mt-0.5 uppercase">
          {activeCategory}
        </h2>
      </div>

      {/* 4. Interactive Word Grid Stage */}
      <div id="playing-grid-wrapper-relative" className="relative flex-grow flex items-center justify-center p-0.5 select-none touch-none bg-slate-950/70 border border-slate-900 rounded-3xl mb-4 shadow-inner">
        
        {/* Floating feedback praises */}
        <div className="absolute inset-0 pointer-events-none z-30 overflow-hidden rounded-3xl">
          <AnimatePresence>
            {feedbackBubbles.map((bubble) => (
              <motion.div
                key={bubble.id}
                initial={{ scale: 0.4, y: 15, opacity: 0 }}
                animate={{ scale: 1.1, y: -25, opacity: 1 }}
                exit={{ scale: 0.8, opacity: 0 }}
                onAnimationComplete={() => handleRemoveBubble(bubble.id)}
                style={{ left: `${bubble.x}%`, top: `${bubble.y}%` }}
                className="absolute transform -translate-x-1/2 bg-gradient-to-r from-emerald-500 to-cyan-500 border border-emerald-300/30 text-white font-extrabold text-xs px-3.5 py-1.5 rounded-full shadow-lg shadow-emerald-500/10 whitespace-nowrap"
              >
                {bubble.text}
              </motion.div>
            ))}
          </AnimatePresence>
        </div>

        {/* Word Search Grid itself */}
        {grid ? (
          <div
            ref={gridRef}
            id="word-search-playing-grid"
            onMouseLeave={handleEndSelection}
            onTouchMove={handleTouchMove}
            onTouchEnd={handleEndSelection}
            onMouseUp={handleEndSelection}
            className="grid w-full aspect-square p-2.5 sm:p-4 touch-none cursor-pointer"
            style={{
              gridTemplateColumns: `repeat(${grid.size}, minmax(0, 1fr))`,
              gridTemplateRows: `repeat(${grid.size}, minmax(0, 1fr))`,
              gap: '4px' // Standard grid gap
            }}
          >
            {grid.cells.map((rowChars, r) =>
              rowChars.map((char, c) => {
                const isSelected = isCellInSelection(r, c);
                const highlightColor = getCellHighlightColor(r, c);

                return (
                  <div
                    key={`${r}-${c}`}
                    data-cell-index={`${r}-${c}`}
                    data-row={r}
                    data-col={c}
                    onMouseDown={() => handleStartSelection(r, c)}
                    onMouseEnter={() => handleHoverCell(r, c)}
                    onTouchStart={() => handleStartSelection(r, c)}
                    className="aspect-square relative flex items-center justify-center select-none rounded-lg font-mono font-black"
                  >
                    {/* Background indicators */}
                    <div
                      className={`
                        absolute inset-0 rounded-lg transition-all duration-150
                        ${isSelected ? 'bg-indigo-500 text-white scale-105 shadow-md shadow-indigo-500/20' : ''}
                      `}
                      style={{
                        backgroundColor: isSelected ? undefined : highlightColor || 'transparent'
                      }}
                    />

                    {/* Word Character Display */}
                    <span 
                      className={`
                        relative z-10 text-sm sm:text-base md:text-lg tracking-normal font-black
                        ${isSelected ? 'text-white font-black' : highlightColor ? 'text-white' : 'text-slate-300'}
                      `}
                    >
                      {char}
                    </span>
                  </div>
                );
              })
            )}
          </div>
        ) : (
          <div className="text-xs text-slate-500 font-mono animate-pulse">Building search grid...</div>
        )}
      </div>

      {/* 5. Clues / Word Find Bank drawer */}
      <div id="playing-stage-clues" className="bg-slate-900 border border-slate-800 rounded-2xl p-4 flex-shrink-0">
        <div className="flex items-center justify-between mb-3 border-b border-slate-800/60 pb-2">
          <span className="text-[10px] text-slate-400 font-extrabold uppercase tracking-widest leading-none">
            WORDS TO RETRIEVE ({grid?.wordPositions.filter((p) => p.found).length || 0}/{grid?.wordPositions.length || 0})
          </span>
        </div>

        <div className="flex flex-wrap gap-2">
          {grid?.wordPositions.map((pos) => {
            const isFound = pos.found;
            return (
              <span
                key={pos.word}
                className={`
                  px-3 py-1.5 rounded-xl text-xs font-bold font-mono border transition-all duration-300 flex items-center gap-1.5
                  ${isFound 
                    ? 'bg-slate-950/30 border-emerald-500/20 text-emerald-400/80 line-through opacity-60 font-medium' 
                    : 'bg-slate-850 border-slate-800 text-slate-200 hover:border-slate-700'
                  }
                `}
              >
                {isFound && <div className="w-2 h-2 bg-emerald-400 rounded-full" />}
                {pos.rawWord}
              </span>
            );
          })}
        </div>
      </div>

      {/* 6. Level Celebration Victory Popup */}
      <AnimatePresence>
        {showWinPopup && (
          <div
            id="victory-screen-overlay"
            className="fixed inset-0 bg-slate-950/90 z-50 flex items-center justify-center p-4 select-none text-white overflow-hidden"
          >
            {/* Lightweight canvas confetti sparkles behind or around popup */}
            <Confetti />

            <motion.div
              id="victory-card-panel"
              initial={{ scale: 0.85, opacity: 0, y: 30 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.85, opacity: 0 }}
              transition={{ type: 'spring', stiffness: 120, damping: 20 }}
              className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-sm p-6 sm:p-7 shadow-2xl relative text-center"
            >
              <div className="absolute -top-12 left-1/2 transform -translate-x-1/2 w-24 h-24 bg-gradient-to-br from-amber-400 to-yellow-500 rounded-3xl flex items-center justify-center shadow-lg shadow-amber-500/25 rotate-12">
                <Trophy className="w-12 h-12 text-slate-950 fill-slate-950 -rotate-12 animate-wiggle" />
              </div>

              <div className="mt-14 mb-6">
                <span className="text-[10px] text-amber-400 font-extrabold uppercase tracking-widest leading-none bg-amber-400/10 py-1.5 px-3 rounded-full border border-amber-400/10">
                  {isDailyChallengeMode ? 'DAILY BONUS WON' : 'LEVEL CLEARED'}
                </span>
                <h2 className="text-3xl font-black mt-3.5 tracking-tight text-white leading-none">
                  {isDailyChallengeMode ? 'Daily Crown!' : 'Awesome Job!'}
                </h2>
              </div>

              {/* Sequential visual delay stars reveal */}
              <div className="flex justify-center gap-2 mb-6">
                {[1, 2, 3].map((starIdx) => (
                  <motion.div
                    key={starIdx}
                    initial={{ scale: 0, rotate: -45 }}
                    animate={{ scale: 1, rotate: 0 }}
                    transition={{ delay: 0.3 + starIdx * 0.15, type: 'spring' }}
                  >
                    <Star
                      className={`w-9 h-9 ${
                        starIdx <= winStars 
                          ? 'fill-current text-yellow-400 text-amber-400 drop-shadow-[0_0_12px_rgba(251,191,36,0.4)]' 
                          : 'text-slate-700 fill-slate-800'
                      }`}
                    />
                  </motion.div>
                ))}
              </div>

              {/* Account distribution stats */}
              <div className="bg-slate-950/60 border border-slate-850 rounded-2xl p-4 mb-6 text-center">
                <div className="text-[10px] text-slate-500 font-bold uppercase tracking-wider">Rewards Distribution</div>
                
                <div className="flex items-center justify-center gap-6 mt-2">
                  <div>
                    <div className="text-amber-400 font-black text-xl flex items-center gap-1.5 justify-center">
                      <Coins className="w-5 h-5 fill-current text-amber-500" />
                      +{winCoinsEarned}
                    </div>
                    <div className="text-[9px] text-slate-400 font-semibold mt-0.5">Coins Added</div>
                  </div>

                  <div className="w-px h-8 bg-slate-850" />

                  <div>
                    <div className="text-[#a855f7] font-black text-xl flex items-center gap-1.5 justify-center">
                      <Sparkles className="w-5 h-5 text-[#a855f7]" />
                      +{winStars === 3 ? '1 Hint' : '0 Hints'}
                    </div>
                    <div className="text-[9px] text-slate-400 font-semibold mt-0.5">3-Star Payout</div>
                  </div>
                </div>

                <div className="text-[10px] text-slate-500 font-mono mt-3.5 leading-tight pt-2 border-t border-slate-850/60">
                  Solve Time: <span className="font-extrabold text-slate-300">{formatTime(seconds)}</span>
                </div>
              </div>

              {/* Awarded badges warning */}
              {streakBadge && (
                <div className="mb-6 bg-cyan-950/20 border border-cyan-800/35 text-cyan-400 p-2.5 rounded-xl text-xs flex gap-1.5 items-center justify-center font-extrabold uppercase tracking-wide">
                  <Flame className="w-4 h-4 text-cyan-400 animate-bounce" />
                  {streakBadge}
                </div>
              )}

              {/* Navigation button arrays */}
              <div className="flex flex-col gap-2">
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => {
                    audio.playClick();
                    if (isDailyChallengeMode) {
                      initLevel(); // Replay or close
                    } else {
                      onGoToNextLevel();
                    }
                  }}
                  className="w-full bg-gradient-to-r from-emerald-500 to-cyan-500 text-white font-extrabold text-base py-3 px-6 rounded-2xl shadow-xl shadow-emerald-500/20 border border-emerald-400/20 hover:shadow-cyan-500/30 flex items-center justify-center gap-2 cursor-pointer transition-all outline-none"
                >
                  {isDailyChallengeMode ? 'REPLAY CHALLENGE' : 'PROCEED TO NEXT LEVEL'}
                  <ChevronRight className="w-5 h-5 text-white" />
                </motion.button>

                <button
                  onClick={() => {
                    audio.playClick();
                    initLevel();
                  }}
                  className="w-full text-slate-400 hover:text-white font-bold text-xs uppercase tracking-widest py-3 border border-slate-800 rounded-xl hover:bg-slate-850 cursor-pointer transition-all duration-150"
                >
                  REPLAY PUZZLE
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
