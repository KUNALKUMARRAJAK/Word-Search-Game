/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type WordCategory = 'Cities' | 'Countries' | 'Animals' | 'Fruits' | 'Sports' | 'Space' | 'Colors' | 'Food';

export interface WordPosition {
  rawWord: string;
  word: string; // Uppercased
  found: boolean;
  coords: { r: number; c: number }[]; // Ordered coordinates of the word in grid
}

export interface GridCell {
  r: number;
  c: number;
  char: string;
}

export interface PuzzleGrid {
  size: number;
  cells: string[][]; // 2D array of uppercase characters
  wordPositions: WordPosition[];
}

export interface LevelProgress {
  levelNumber: number;
  stars: number; // 0 (unplayed/unsolved), 1, 2, or 3
  bestTime?: number; // in seconds
}

export interface UserProgress {
  currentLevel: number; // Highest unlocked level
  coins: number;
  hintsCount: number;
  levels: { [levelNum: number]: LevelProgress };
  lastDailyChallengeCompletedDate?: string; // YYYY-MM-DD
  badges: string[]; // List of badge IDs earned
}

export interface SelectionState {
  start: { r: number; c: number } | null;
  current: { r: number; c: number } | null;
  selectedCells: { r: number; c: number }[];
}

export interface FeedbackText {
  id: string;
  text: string;
  x: number;
  y: number;
}
