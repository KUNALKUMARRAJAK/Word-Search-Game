/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Calendar, Timer, Award, CheckCircle, ChevronLeft, ArrowRight, Play, RefreshCw } from 'lucide-react';
import { generatePuzzle, formatTime } from '../utils/words';
import { WordCategory, PuzzleGrid } from '../types';
import { audio } from '../utils/audio';

interface DailyChallengeProps {
  onChallengeCompleted: (coinsEarned: number, badgeId: string) => void;
  lastDateCompleted: string | undefined;
}

export default function DailyChallenge({ onChallengeCompleted, lastDateCompleted }: DailyChallengeProps) {
  // Determine date key
  const [todayStr, setTodayStr] = useState('');
  const [timeLeftStr, setTimeLeftStr] = useState('');
  const [playClicked, setPlayClicked] = useState(false);
  const [isCompleted, setIsCompleted] = useState(false);

  useEffect(() => {
    const d = new Date();
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    const dStr = `${y}-${m}-${day}`;
    setTodayStr(dStr);

    if (lastDateCompleted === dStr) {
      setIsCompleted(true);
    }

    // Calculated Midnight ticking decrementer
    const updateCountdown = () => {
      const now = new Date();
      const tomorrow = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1, 0, 0, 0);
      const diffMs = tomorrow.getTime() - now.getTime();
      
      const hours = Math.floor(diffMs / (1000 * 60 * 60));
      const minutes = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));
      const seconds = Math.floor((diffMs % (1000 * 60)) / 1000);

      setTimeLeftStr(
        `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`
      );
    };

    updateCountdown();
    const timer = setInterval(updateCountdown, 1000);
    return () => clearInterval(timer);
  }, [lastDateCompleted]);

  const handleStartPlay = () => {
    audio.playClick();
    setPlayClicked(true);
  };

  return (
    <div id="daily-challenge-screen" className="bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-xl relative overflow-hidden flex flex-col text-white max-w-sm mx-auto">
      {/* Decorative calendar watermark */}
      <Calendar className="absolute -top-12 -right-12 w-40 h-40 text-slate-800/10 pointer-events-none" />

      {/* Top Header */}
      <div className="flex items-center gap-2 mb-4">
        <div className="bg-gradient-to-tr from-rose-500 to-amber-500 p-2.5 rounded-2xl shadow">
          <Calendar className="w-5 h-5 text-white" />
        </div>
        <div>
          <h3 className="text-lg font-black tracking-tight text-transparent bg-clip-text bg-gradient-to-r from-rose-400 to-amber-300">
            Daily Challenge
          </h3>
          <p className="text-[10px] text-slate-400 font-semibold uppercase tracking-wider">
            {todayStr}
          </p>
        </div>
      </div>

      {/* Already Finished State */}
      {isCompleted ? (
        <div className="text-center py-6 flex flex-col items-center">
          <div className="w-16 h-16 bg-rose-500/10 text-rose-400 rounded-full flex items-center justify-center border border-rose-500/20 mb-4 animate-bounce">
            <CheckCircle className="w-8 h-8 fill-current text-rose-500 stroke-slate-900" />
          </div>
          <h4 className="font-extrabold text-lg text-white">Daily Crown Claimed!</h4>
          <p className="text-slate-400 text-xs mt-1.5 px-6">
            Fantastic job! You've conquered today's custom layout and received <span className="text-amber-400 font-extrabold">150 Coins</span>.
          </p>

          <div className="mt-6 p-4 bg-slate-950/60 border border-slate-850 rounded-2xl text-center w-full">
            <div className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">NEXT CHALLENGE IN</div>
            <div className="text-xl font-mono font-black text-rose-400 mt-1 flex items-center justify-center gap-1.5">
              <Timer className="w-5 h-5 text-rose-400 animate-pulse" />
              {timeLeftStr}
            </div>
          </div>
        </div>
      ) : (
        <div className="flex flex-col">
          <p className="text-slate-300 text-xs leading-relaxed mb-4">
            Test your limits: discover all words before the 120-second timer runs dry. Cleanse today's puzzle to earn rare badges and double token payouts!
          </p>

          {/* Quick Info Grid */}
          <div className="grid grid-cols-2 gap-2 mb-5">
            <div className="bg-slate-950/40 border border-slate-850 rounded-2xl p-3 text-center">
              <div className="text-[9px] text-slate-500 font-bold uppercase tracking-wider">Time Limit</div>
              <div className="text-xs font-black text-slate-200 mt-1">120 Seconds</div>
            </div>
            <div className="bg-slate-950/40 border border-slate-850 rounded-2xl p-3 text-center">
              <div className="text-[9px] text-slate-500 font-bold uppercase tracking-wider">Rewards</div>
              <div className="text-xs font-black text-amber-400 mt-1 flex items-center justify-center gap-1">
                +150 Coins
              </div>
            </div>
          </div>

          {/* Start Daily Button */}
          {!playClicked ? (
            <motion.button
              onClick={handleStartPlay}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className="w-full bg-gradient-to-r from-rose-500 to-amber-500 text-white font-extrabold py-3 px-6 rounded-2xl flex items-center justify-center gap-2 shadow-lg shadow-rose-500/20 text-sm cursor-pointer hover:shadow-amber-500/20 transition-all border border-rose-400/20"
            >
              <Play className="w-4 h-4 fill-current text-white" />
              LAUNCH SPEED RUN
            </motion.button>
          ) : (
            <div className="text-center py-2 text-xs font-semibold text-rose-400 flex items-center justify-center gap-1.5 bg-rose-500/5 border border-rose-500/10 rounded-xl">
              <RefreshCw className="w-3.5 h-3.5 animate-spin" />
              Game Board Prepped. Tap Play above in Menu.
            </div>
          )}

          {/* Live countdown */}
          <div className="flex items-center justify-center gap-1.5 mt-4 text-[10px] text-slate-400 font-semibold uppercase tracking-wider">
            <span>Challenge resets in:</span>
            <span className="font-mono text-slate-200 font-extrabold">{timeLeftStr}</span>
          </div>
        </div>
      )}
    </div>
  );
}
