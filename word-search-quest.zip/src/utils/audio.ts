/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

class AudioManager {
  private ctx: AudioContext | null = null;
  private masterVolume: GainNode | null = null;
  private musicVolume: GainNode | null = null;
  private sfxVolume: GainNode | null = null;
  
  private musicInterval: any = null;
  private currentNotes: OscillatorNode[] = [];

  private sfxEnabled = true;
  private musicEnabled = true;

  constructor() {
    // Lazy initialized on first user interaction
    // to pass browser autoplay constraints.
  }

  private init() {
    if (this.ctx) return;
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      this.ctx = new AudioCtx();
      
      this.masterVolume = this.ctx.createGain();
      this.masterVolume.gain.setValueAtTime(0.6, this.ctx.currentTime);
      this.masterVolume.connect(this.ctx.destination);

      this.musicVolume = this.ctx.createGain();
      this.musicVolume.gain.setValueAtTime(this.musicEnabled ? 0.15 : 0, this.ctx.currentTime);
      this.musicVolume.connect(this.masterVolume);

      this.sfxVolume = this.ctx.createGain();
      this.sfxVolume.gain.setValueAtTime(this.sfxEnabled ? 0.35 : 0, this.ctx.currentTime);
      this.sfxVolume.connect(this.masterVolume);

      if (this.musicEnabled) {
        this.startMusic();
      }
    } catch (e) {
      console.warn("Web Audio API not supported", e);
    }
  }

  // Setters for enabling/disabling volume buses
  public setSfxEnabled(enabled: boolean) {
    this.sfxEnabled = enabled;
    if (this.sfxVolume && this.ctx) {
      this.sfxVolume.gain.setValueAtTime(enabled ? 0.35 : 0, this.ctx.currentTime);
    }
  }

  public setMusicEnabled(enabled: boolean) {
    this.musicEnabled = enabled;
    if (this.musicVolume && this.ctx) {
      this.musicVolume.gain.setValueAtTime(enabled ? 0.15 : 0, this.ctx.currentTime);
    }
    if (enabled) {
      this.init();
      this.startMusic();
    } else {
      this.stopMusic();
    }
  }

  public isSfxEnabled() {
    return this.sfxEnabled;
  }

  public isMusicEnabled() {
    return this.musicEnabled;
  }

  // SFX: Click
  public playClick() {
    this.init();
    if (!this.sfxEnabled || !this.ctx || !this.sfxVolume) return;

    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    
    osc.type = 'sine';
    osc.frequency.setValueAtTime(400, this.ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(120, this.ctx.currentTime + 0.08);

    gain.gain.setValueAtTime(0.15, this.ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.01, this.ctx.currentTime + 0.08);

    osc.connect(gain);
    gain.connect(this.sfxVolume);
    
    osc.start();
    osc.stop(this.ctx.currentTime + 0.08);
  }

  // SFX: Found Word (rising beautiful chime arpeggio)
  public playWordFound() {
    this.init();
    if (!this.sfxEnabled || !this.ctx || !this.sfxVolume) return;

    const now = this.ctx.currentTime;
    const notes = [523.25, 659.25, 783.99, 1046.50]; // C5, E5, G5, C6 arpeggio
    
    notes.forEach((freq, idx) => {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, now + idx * 0.07);

      gain.gain.setValueAtTime(0, now);
      gain.gain.linearRampToValueAtTime(0.12, now + idx * 0.07 + 0.01);
      gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.07 + 0.4);

      osc.connect(gain);
      gain.connect(this.sfxVolume);

      osc.start(now + idx * 0.07);
      osc.stop(now + idx * 0.07 + 0.4);
    });
  }

  // SFX: Level Completion fanfare (joyous chord resolution)
  public playWin() {
    this.init();
    if (!this.sfxEnabled || !this.ctx || !this.sfxVolume) return;

    const now = this.ctx.currentTime;
    // Elegant major progression: C5 - E5 - G5 -> F5 - A5 - C6 -> G5 - B5 - D6 -> C6 - E6 - G6
    const chords = [
      [261.63, 329.63, 392.00], // C chord
      [349.23, 440.00, 523.25], // F chord
      [392.00, 493.88, 587.33], // G chord
      [523.25, 659.25, 783.99]  // C high chord
    ];

    chords.forEach((chord, chordIdx) => {
      chord.forEach((freq) => {
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();

        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, now + chordIdx * 0.18);

        gain.gain.setValueAtTime(0, now);
        gain.gain.linearRampToValueAtTime(0.08, now + chordIdx * 0.18 + 0.02);
        gain.gain.exponentialRampToValueAtTime(0.001, now + chordIdx * 0.18 + 0.6);

        osc.connect(gain);
        gain.connect(this.sfxVolume);

        osc.start(now + chordIdx * 0.18);
        osc.stop(now + chordIdx * 0.18 + 0.61);
      });
    });
  }

  // SFX: Sound when selecting (short click/pop)
  public playTick() {
    this.init();
    if (!this.sfxEnabled || !this.ctx || !this.sfxVolume) return;

    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(800, this.ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(300, this.ctx.currentTime + 0.02);

    gain.gain.setValueAtTime(0.05, this.ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.02);

    osc.connect(gain);
    gain.connect(this.sfxVolume);

    osc.start();
    osc.stop(this.ctx.currentTime + 0.02);
  }

  // SFX: Refill hints sound
  public playRefill() {
    this.init();
    if (!this.sfxEnabled || !this.ctx || !this.sfxVolume) return;

    const now = this.ctx.currentTime;
    const freqs = [440, 554.37, 659.25, 880]; // A major chime

    freqs.forEach((f, i) => {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(f, now + i * 0.05);

      gain.gain.setValueAtTime(0, now);
      gain.gain.linearRampToValueAtTime(0.05, now + i * 0.05 + 0.01);
      gain.gain.exponentialRampToValueAtTime(0.001, now + i * 0.05 + 0.25);

      osc.connect(gain);
      gain.connect(this.sfxVolume);

      osc.start(now + i * 0.05);
      osc.stop(now + i * 0.05 + 0.25);
    });
  }

  // Procedural background music: smooth, calming melody
  private startMusic() {
    if (!this.musicEnabled || this.musicInterval) return;
    this.init();
    if (!this.ctx || !this.musicVolume) return;

    let beat = 0;
    // Calming pentatonic scale notes: C4, D4, E4, G4, A4, C5, D5, E5, G5, A5
    const scale = [261.63, 293.66, 329.63, 392.00, 440.00, 523.25, 587.33, 659.25, 783.99, 880.00];
    
    // Ambient chord progression pad (gentle hum on background)
    const playChord = (freqs: number[], duration: number) => {
      if (!this.ctx || !this.musicVolume || !this.musicEnabled) return;
      
      const now = this.ctx.currentTime;
      const oscs = freqs.map(f => {
        const osc = this.ctx.createOscillator();
        osc.type = 'sine';
        osc.frequency.value = f;
        return osc;
      });

      const gain = this.ctx.createGain();
      gain.gain.setValueAtTime(0, now);
      gain.gain.linearRampToValueAtTime(0.04, now + 1.0); // Slow fade-in
      gain.gain.exponentialRampToValueAtTime(0.001, now + duration); // Slow fade-out

      oscs.forEach(osc => {
        osc.connect(gain);
        osc.start(now);
        osc.stop(now + duration);
        this.currentNotes.push(osc);
      });
      gain.connect(this.musicVolume);
    };

    // Low-overhead background runner
    this.musicInterval = setInterval(() => {
      if (!this.ctx || !this.musicEnabled) return;
      
      this.currentNotes = this.currentNotes.filter(n => {
        try {
          return n.frequency.value > 0;
        } catch {
          return false;
        }
      });

      // Play soft chord every 8 beats
      if (beat % 8 === 0) {
        // Chord indices
        const step = (beat / 8) % 4;
        let chord: number[] = [];
        if (step === 0) chord = [261.63, 329.63, 392.00, 523.25]; // C Major
        else if (step === 1) chord = [293.66, 349.23, 440.00, 587.33]; // D minor 7
        else if (step === 2) chord = [329.63, 392.00, 493.88, 659.25]; // E minor 7
        else chord = [349.23, 440.00, 523.25, 698.46]; // F Major 7

        playChord(chord, 6.0);
      }

      // Play soft melodic chime sometimes
      if (beat % 2 === 0 && Math.random() > 0.4) {
        const now = this.ctx.currentTime;
        const noteIndex = Math.floor(Math.random() * scale.length);
        const freq = scale[noteIndex];

        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();

        osc.type = 'triangle';
        osc.frequency.setValueAtTime(freq, now);

        gain.gain.setValueAtTime(0, now);
        gain.gain.linearRampToValueAtTime(0.03, now + 0.1);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 2.0);

        osc.connect(gain);
        gain.connect(this.musicVolume);

        osc.start(now);
        osc.stop(now + 2.0);
        this.currentNotes.push(osc);
      }

      beat++;
    }, 1500);
  }

  private stopMusic() {
    if (this.musicInterval) {
      clearInterval(this.musicInterval);
      this.musicInterval = null;
    }
    this.currentNotes.forEach(n => {
      try { n.stop(); } catch {}
    });
    this.currentNotes = [];
  }
}

export const audio = new AudioManager();
