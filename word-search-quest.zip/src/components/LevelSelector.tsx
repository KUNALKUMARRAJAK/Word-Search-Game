/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import { motion } from 'motion/react';
import { Lock, Star, ChevronLeft, ChevronRight, Award } from 'lucide-react';
import { UserProgress } from '../types';
import { audio } from '../utils/audio';

interface LevelSelectorProps {
  progress: UserProgress;
  onSelectLevel: (levelNum: number) => void;
  onClose: () => void;
}

export default function LevelSelector({ progress, onSelectLevel, onClose }: LevelSelectorProps) {
  const [currentPage, setCurrentPage] = useState(() => {
    // Start page surrounding the player's current level
    return Math.floor((progress.currentLevel - 1) / 25);
  });

  const totalLevels = 500;
  const levelsPerPage = 25;
  const totalPages = Math.ceil(totalLevels / levelsPerPage);

  const startLevel = currentPage * levelsPerPage + 1;
  const endLevel = Math.min(startLevel + levelsPerPage - 1, totalLevels);

  const handleSelect = (levelNum: number) => {
    if (levelNum > progress.currentLevel) return; // Locked
    audio.playClick();
    onSelectLevel(levelNum);
  };

  const nextPage = () => {
    if (currentPage < totalPages - 1) {
      audio.playClick();
      setCurrentPage(currentPage + 1);
    }
  };

  const prevPage = () => {
    if (currentPage > 0) {
      audio.playClick();
      setCurrentPage(currentPage - 1);
    }
  };

  // Extract stars awarded from progress mapping
  const getLevelStars = (levelNum: number) => {
    return progress.levels[levelNum]?.stars || 0;
  };

  return (
    <div
      id="level-selector-overlay"
      className="fixed inset-0 bg-slate-950/80 backdrop-blur-md z-40 flex items-center justify-center p-4 select-none text-white overflow-hidden"
    >
      <motion.div
        id="level-selector-card"
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-lg p-5 sm:p-6 shadow-2xl relative flex flex-col max-h-[85vh]"
      >
        {/* Header */}
        <div id="level-selector-header" className="flex items-center justify-between mb-4 flex-shrink-0">
          <div>
            <h2 className="text-2xl font-black tracking-tight text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-cyan-300">
              Select Level
            </h2>
            <p className="text-xs text-slate-400">
              Unlock up to 500 hand-curated search quests!
            </p>
          </div>
          <button
            id="level-selector-close-btn"
            onClick={() => {
              audio.playClick();
              onClose();
            }}
            className="text-slate-400 hover:text-white bg-slate-800 p-2 rounded-xl transition cursor-pointer"
          >
            ✕
          </button>
        </div>

        {/* Level Stats Widget */}
        <div id="level-selector-stats-bar" className="bg-slate-950/50 rounded-2xl p-3 border border-slate-800/60 mb-5 flex justify-around text-center flex-shrink-0">
          <div>
            <div className="text-yellow-400 font-extrabold text-lg flex items-center gap-1 justify-center">
              <Star className="w-4 h-4 fill-current text-yellow-400" />
              {Object.values(progress.levels).reduce((sum, lvl) => sum + (lvl.stars || 0), 0)}
            </div>
            <div className="text-[10px] text-slate-500 font-bold uppercase tracking-wider">Total Stars</div>
          </div>
          <div className="border-r border-slate-800" />
          <div>
            <div className="text-cyan-400 font-extrabold text-lg flex items-center gap-1 justify-center">
              <Award className="w-4 h-4 text-cyan-400" />
              {progress.currentLevel - 1} / 500
            </div>
            <div className="text-[10px] text-slate-500 font-bold uppercase tracking-wider">Levels Beat</div>
          </div>
        </div>

        {/* Pagination Header Controls & Indicator */}
        <div id="level-pagination-controls" className="flex items-center justify-between px-2 mb-3 flex-shrink-0 text-sm">
          <button
            onClick={prevPage}
            disabled={currentPage === 0}
            className="p-2 h-9 w-9 bg-slate-800 rounded-lg hover:bg-slate-700 disabled:opacity-30 disabled:pointer-events-none flex items-center justify-center cursor-pointer transition text-white"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>
          
          <span className="font-extrabold tracking-wide text-slate-300">
            Levels {startLevel} - {endLevel}
          </span>

          <button
            onClick={nextPage}
            disabled={currentPage === totalPages - 1}
            className="p-2 h-9 w-9 bg-slate-800 rounded-lg hover:bg-slate-700 disabled:opacity-30 disabled:pointer-events-none flex items-center justify-center cursor-pointer transition text-white"
          >
            <ChevronRight className="w-5 h-5" />
          </button>
        </div>

        {/* Levels Grid Container */}
        <div id="level-buttons-grid-viewport" className="overflow-y-auto pr-1 flex-grow scrollbar-thin scrollbar-thumb-slate-800 p-1">
          <div className="grid grid-cols-5 gap-3">
            {Array.from({ length: endLevel - startLevel + 1 }).map((_, idx) => {
              const levelNum = startLevel + idx;
              const isLocked = levelNum > progress.currentLevel;
              const isCompleted = levelNum < progress.currentLevel;
              const isActive = levelNum === progress.currentLevel;
              const stars = getLevelStars(levelNum);

              return (
                <div key={levelNum} className="flex flex-col items-center">
                  <button
                    onClick={() => handleSelect(levelNum)}
                    className={`
                      aspect-square w-full rounded-2xl flex flex-col items-center justify-center font-black relative overflow-hidden transition-all duration-200 cursor-pointer border shadow-md
                      ${isLocked 
                        ? 'bg-slate-950/40 text-slate-600 border-slate-900/60 opacity-60 cursor-not-allowed' 
                        : isCompleted
                          ? 'bg-radial from-slate-800 to-slate-900 text-emerald-400 border-emerald-500/20 hover:scale-105 hover:border-emerald-500/40' 
                          : 'bg-gradient-to-br from-emerald-500 to-cyan-500 text-white border-emerald-300/30 shadow-lg shadow-emerald-500/20 hover:scale-110'
                      }
                    `}
                  >
                    {isLocked ? (
                      <Lock className="w-5 h-5 text-slate-700" />
                    ) : (
                      <span className="text-base font-black leading-none">{levelNum}</span>
                    )}

                    {/* Miniature star tier inside unlocked level */}
                    {!isLocked && (
                      <div className="flex gap-0.5 mt-1.5 justify-center">
                        {[1, 2, 3].map((starIdx) => (
                          <Star
                            key={starIdx}
                            className={`w-2.5 h-2.5 ${
                              starIdx <= stars 
                                ? 'fill-current text-amber-400 text-yellow-400' 
                                : 'text-slate-700 fill-slate-850'
                            }`}
                          />
                        ))}
                      </div>
                    )}
                  </button>
                </div>
              );
            })}
          </div>
        </div>

        {/* Footer info message */}
        <div className="text-center text-[10px] text-slate-500 mt-4 pt-3 border-t border-slate-800/60 flex-shrink-0 font-medium">
          Note: Locking is sequential. Clear level {progress.currentLevel} to proceed.
        </div>
      </motion.div>
    </div>
  );
}
