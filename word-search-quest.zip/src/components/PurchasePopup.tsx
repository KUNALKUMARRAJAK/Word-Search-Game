/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Coins, Sparkles, AlertCircle } from 'lucide-react';
import { audio } from '../utils/audio';

interface PurchasePopupProps {
  currentCoins: number;
  currentHints: number;
  onPurchase: (hintsGained: number, cost: number) => void;
  onClose: () => void;
}

interface ShopBundle {
  id: string;
  hints: number;
  cost: number;
  title: string;
  isPopular?: boolean;
}

export default function PurchasePopup({ currentCoins, currentHints, onPurchase, onClose }: PurchasePopupProps) {
  const [errorWord, setErrorWord] = useState<string | null>(null);
  
  // High-value item packs
  const bundles: ShopBundle[] = [
    { id: 'starter', hints: 3, cost: 100, title: 'Starter Chimes' },
    { id: 'adventurer', hints: 8, cost: 200, title: 'Quest Pack', isPopular: true },
    { id: 'master', hints: 25, cost: 500, title: 'Infinite Vision' }
  ];

  const handleBuy = (bundle: ShopBundle) => {
    if (currentCoins < bundle.cost) {
      audio.playClick();
      setErrorWord(`Insufficient Coins! Need ${bundle.cost - currentCoins} more.`);
      setTimeout(() => setErrorWord(null), 3500);
      return;
    }

    // Success flow
    audio.playRefill();
    onPurchase(bundle.hints, bundle.cost);
  };

  return (
    <div
      id="purchase-store-overlay"
      className="fixed inset-0 bg-slate-950/85 backdrop-blur-sm z-55 flex items-center justify-center p-4 select-none text-white overflow-hidden"
    >
      <motion.div
        id="purchase-dialog-card"
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-sm p-6 shadow-2xl relative flex flex-col"
      >
        {/* Floating sparkles aesthetic decoration */}
        <div className="absolute -top-3 -right-3 w-10 h-10 bg-amber-500 rounded-full flex items-center justify-center shadow-lg shadow-amber-500/30 animate-pulse">
          <Sparkles className="w-5 h-5 text-zinc-900 fill-current" />
        </div>

        {/* Title Block */}
        <div className="text-center mb-6">
          <h3 className="text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-amber-400 to-yellow-300">
            Get More Hints
          </h3>
          <p className="text-xs text-slate-400 mt-1">
            Running low? Trade your gold coins for instant vision!
          </p>
        </div>

        {/* Account ledger bar */}
        <div className="grid grid-cols-2 gap-2 bg-slate-950/60 rounded-2xl p-3 border border-slate-850 mb-5 text-center">
          <div>
            <div className="text-[10px] text-slate-500 font-bold uppercase tracking-wider">Your Coins</div>
            <div className="text-amber-400 font-black text-base flex items-center gap-1 justify-center mt-0.5">
              <Coins className="w-4 h-4 fill-current text-amber-500" />
              {currentCoins}
            </div>
          </div>
          <div className="border-l border-slate-850" />
          <div>
            <div className="text-[10px] text-slate-500 font-bold uppercase tracking-wider">Your Hints</div>
            <div className="text-[#a855f7] font-black text-base flex items-center gap-1 justify-center mt-0.5">
              <Sparkles className="w-4 h-4 text-[#a855f7]" />
              {currentHints}
            </div>
          </div>
        </div>

        {/* Bundle options list */}
        <div className="space-y-3">
          {bundles.map((bundle) => {
            const hasEnough = currentCoins >= bundle.cost;
            return (
              <motion.button
                key={bundle.id}
                onClick={() => handleBuy(bundle)}
                whileHover={hasEnough ? { scale: 1.02, x: 2 } : {}}
                whileTap={hasEnough ? { scale: 0.98 } : {}}
                className={`
                  w-full rounded-2xl p-4 border transition-all duration-200 flex items-center justify-between text-left relative cursor-pointer
                  ${bundle.isPopular 
                    ? 'bg-slate-800/80 border-cyan-500/40 shadow-md shadow-cyan-500/5' 
                    : 'bg-slate-850/50 border-slate-800 hover:bg-slate-800'
                  }
                  ${!hasEnough ? 'opacity-85 border-slate-800/40' : ''}
                `}
              >
                {bundle.isPopular && (
                  <span className="absolute -top-2.5 left-4 bg-cyan-500 text-[9px] font-black tracking-widest text-zinc-950 px-2 py-0.5 rounded-full uppercase shadow">
                    BEST CHOICE
                  </span>
                )}
                
                <div>
                  <h4 className="font-extrabold text-sm text-slate-200">{bundle.title}</h4>
                  <p className="text-xl font-black text-white flex items-center gap-1.5 mt-0.5">
                    +{bundle.hints} Hints
                  </p>
                </div>

                <div className={`
                  px-4 py-2 rounded-xl flex items-center gap-1.5 font-extrabold transition-all duration-150
                  ${hasEnough 
                    ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30 font-black' 
                    : 'bg-slate-950 text-slate-600 border border-slate-900 line-through'
                  }
                `}>
                  <Coins className="w-4 h-4 fill-current text-amber-500" />
                  {bundle.cost}
                </div>
              </motion.button>
            );
          })}
        </div>

        {/* Error notification bar */}
        <AnimatePresence>
          {errorWord && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="mt-4 bg-rose-500/10 border border-rose-500/20 text-rose-400 p-2.5 rounded-xl text-xs flex gap-1.5 items-center justify-center font-semibold text-center"
            >
              <AlertCircle className="w-4 h-4 flex-shrink-0" />
              {errorWord}
            </motion.div>
          )}
        </AnimatePresence>

        {/* Close Store Button */}
        <button
          onClick={() => {
            audio.playClick();
            onClose();
          }}
          className="mt-6 w-full text-center text-slate-400 hover:text-white font-black text-xs uppercase tracking-widest py-3 border border-slate-800 rounded-xl hover:bg-slate-850 cursor-pointer transition-all duration-150"
        >
          CLOSE SHOP
        </button>
      </motion.div>
    </div>
  );
}
